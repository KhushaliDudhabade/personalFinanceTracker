import React from 'react'
import { Button, Modal, Form, Input, DatePicker, Select } from 'antd'


function AddExpense({isExpenseModalVisible,handleExpenseCancel,onFinish}) {
    const[form]=Form.useForm();
  return (
    <Modal style={{fontWeight:"600"}} 
           title="Add Expenses"
           visible={isExpenseModalVisible}
           onCancel={handleExpenseCancel}
           footer={null}>

      <Form
        form={form}
        layout="vertical"
        onFinish={(values) => {
          onFinish(values, 'expense');
          form.resetFields(); 
          handleExpenseCancel(); 
        }}
      >

        <Form.Item style={{fontWeight:600}}
        label="Name"
        name="name"
        rules={[{
            required:true,
            message:"Please input the name of the transactions"
        }]}>
         <Input type="text" className='custom-input' />
        </Form.Item>

        <Form.Item style={{fontWeight:600}}
        label="Amount"
        name="amount"
        rules={[{
            required:true,
            message:"Please put the expense amount!"
        }]}>
         <Input type="number" className='custom-input' />
        </Form.Item>

        <Form.Item style={{fontWeight:600}}
        label="Date"
        name="date"
        rules={[{
            required:true,
            message:"Please select the expense date!"
        }]}>
         <DatePicker format="YYYY-MM-DD" className='custom-input' />
         
        </Form.Item>
         
        <Form.Item style={{fontWeight:600}}
        label="Tag"
        name="tag"
        rules={[{
            required:true,
            message:"Please select a tag!"
        }]}>
          <Select className="select-input-2">
            <Select.Option value="Food">Food</Select.Option>
            <Select.Option value="Shopping">Shopping</Select.Option>
            <Select.Option value="Traveling">Traveling</Select.Option>
            <Select.Option value="Residential Bill">Residential Bill</Select.Option>
          </Select>
        </Form.Item>
        
        <Form.Item>
            <Button className="btn btn-blue" htmlType="submit">
                Add Expense
            </Button>
        </Form.Item>
        </Form>

    </Modal>
  )
}

export default AddExpense